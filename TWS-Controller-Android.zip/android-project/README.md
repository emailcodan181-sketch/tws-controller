# TWS Controller - Android APK

Aplicativo Android para controle de fones Bluetooth TWS com tema dark cyberpunk.

## Funcionalidades

- **Detecção automática** do fone TWS (lado esquerdo e direito)
- **Controle de volume individual** por ouvido (L/R)
- **Sincronização de volume** (botão SYNC — move ambos juntos)
- **Volume do microfone** com ativação/mudo independente
- **Bateria** de cada lado (L/R) quando suportado
- **Equalizador** rápido: FLAT / BASS / VOCAL
- **Cancelamento de ruído** (toggle ANC)
- **Scanner Bluetooth** — re-busca o fone

## Como compilar o APK

### Pré-requisitos
- Android Studio Hedgehog ou superior
- Android SDK 34
- JDK 11+

### Passos

```bash
# 1. Abrir o projeto no Android Studio
File → Open → selecione a pasta android-project/

# 2. Sincronizar Gradle
File → Sync Project with Gradle Files

# 3. Gerar APK de debug (para testar)
Build → Build Bundle(s)/APK(s) → Build APK(s)
# APK gerado em: app/build/outputs/apk/debug/app-debug.apk

# 4. Gerar APK de release (assinado)
Build → Generate Signed Bundle/APK → APK
```

### Via linha de comando
```bash
cd android-project
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release-unsigned.apk
```

## Permissões necessárias

| Permissão | Motivo |
|-----------|--------|
| BLUETOOTH_CONNECT | Conectar ao fone |
| BLUETOOTH_SCAN | Detectar dispositivos |
| RECORD_AUDIO | Controle do microfone |
| MODIFY_AUDIO_SETTINGS | Alterar volumes do sistema |
| ACCESS_FINE_LOCATION | Obrigatório para scan BLE no Android ≤11 |

## Compatibilidade

- Android 5.0+ (API 21)
- Fones Bluetooth com perfil A2DP e/ou HFP
- TWS com AVRCP 1.6+ para info de bateria

## Arquitetura

```
MainActivity.java          ← Activity principal com toda a lógica
  ├── BluetoothHeadset     ← Perfil HFP (microfone, chamadas)
  ├── AudioManager         ← Controle de volume (sistema)
  ├── BroadcastReceiver    ← Eventos de conexão BT em tempo real
  └── BluetoothAdapter     ← Scanner e dispositivos pareados

res/layout/activity_main.xml   ← UI dark completa
res/values/styles.xml          ← Tema Material3 dark
res/drawable/                  ← Shapes e LEDs customizados
```

## Nota técnica sobre volumes L/R

O Android não expõe controle de volume por canal (L/R) de forma nativa via API pública. O app usa `AudioManager.STREAM_MUSIC` para volume geral. Para controle real por canal:

1. **Método 1**: `AudioManager.setParameters("volume_left=X;volume_right=Y")` — funciona em alguns fabricantes
2. **Método 2**: Equalizer + `LoudnessEnhancer` do Android via `android.media.audiofx`
3. **Método 3**: Companion App API do fabricante (Samsung, Sony, etc.)

O código está preparado para integrar qualquer um desses métodos na classe `MainActivity`.
