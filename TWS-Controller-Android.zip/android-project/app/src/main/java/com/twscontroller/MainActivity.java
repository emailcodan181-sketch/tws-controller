package com.twscontroller;

import android.Manifest;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.*;
import android.os.*;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    // ──────────────── Bluetooth ────────────────
    private BluetoothAdapter btAdapter;
    private BluetoothHeadset  btHeadset;
    private BluetoothDevice   connectedDevice;
    private boolean leftConnected  = false;
    private boolean rightConnected = false;

    // ──────────────── Audio ────────────────────
    private AudioManager audioManager;

    // ──────────────── UI ──────────────────────
    private SeekBar sbLeft, sbRight, sbMic;
    private TextView tvLeft, tvRight, tvMic;
    private TextView tvDeviceName, tvCodec, tvStatus;
    private TextView tvBatLeft, tvBatRight;
    private View     ledLeft, ledRight;
    private Switch   swLink, swANC, swMic;
    private Button   btnScan;
    private LinearLayout llEqFlat, llEqBass, llEqVocal;

    private boolean volumesLinked = true;
    private boolean scanning      = false;

    private static final int REQ_PERM = 1;

    // ──────────────── Bluetooth profile callback ──
    private final BluetoothProfile.ServiceListener headsetListener =
        new BluetoothProfile.ServiceListener() {
            @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
                btHeadset = (BluetoothHeadset) proxy;
                refreshConnectedDevices();
            }
            @Override public void onServiceDisconnected(int profile) {
                btHeadset = null;
            }
        };

    // ──────────────── Bluetooth state receiver ──
    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action) ||
                BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action) ||
                BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED.equals(action)) {
                new Handler(Looper.getMainLooper())
                    .postDelayed(() -> refreshConnectedDevices(), 800);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        bindViews();
        requestRequiredPermissions();
        initBluetooth();
        setupSliders();
        setupButtons();
    }

    // ──────────────── View binding ──────────────
    private void bindViews() {
        sbLeft      = findViewById(R.id.sb_left);
        sbRight     = findViewById(R.id.sb_right);
        sbMic       = findViewById(R.id.sb_mic);
        tvLeft      = findViewById(R.id.tv_left_val);
        tvRight     = findViewById(R.id.tv_right_val);
        tvMic       = findViewById(R.id.tv_mic_val);
        tvDeviceName= findViewById(R.id.tv_device_name);
        tvCodec     = findViewById(R.id.tv_codec);
        tvStatus    = findViewById(R.id.tv_status);
        tvBatLeft   = findViewById(R.id.tv_bat_left);
        tvBatRight  = findViewById(R.id.tv_bat_right);
        ledLeft     = findViewById(R.id.led_left);
        ledRight    = findViewById(R.id.led_right);
        swLink      = findViewById(R.id.sw_link);
        swANC       = findViewById(R.id.sw_anc);
        swMic       = findViewById(R.id.sw_mic);
        btnScan     = findViewById(R.id.btn_scan);
        llEqFlat    = findViewById(R.id.eq_flat);
        llEqBass    = findViewById(R.id.eq_bass);
        llEqVocal   = findViewById(R.id.eq_vocal);
    }

    // ──────────────── Bluetooth init ────────────
    private void initBluetooth() {
        BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        if (bm == null) return;
        btAdapter = bm.getAdapter();
        if (btAdapter == null || !btAdapter.isEnabled()) {
            tvStatus.setText("BLUETOOTH DESLIGADO");
            return;
        }
        btAdapter.getProfileProxy(this, headsetListener, BluetoothProfile.HEADSET);

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED);
        registerReceiver(btReceiver, filter);

        refreshConnectedDevices();
    }

    // ──────────────── Detect connected TWS ──────
    private void refreshConnectedDevices() {
        if (btAdapter == null) return;

        Set<BluetoothDevice> bonded = btAdapter.getBondedDevices();
        connectedDevice = null;
        leftConnected   = false;
        rightConnected  = false;

        // Check audio manager for active BT device
        if (audioManager.isBluetoothA2dpOn()) {
            // Find connected A2DP device from bonded list
            for (BluetoothDevice dev : bonded) {
                if (dev.getType() != BluetoothDevice.DEVICE_TYPE_CLASSIC &&
                    dev.getType() != BluetoothDevice.DEVICE_TYPE_DUAL) continue;
                // TWS devices usually share name with L/R suffixes or same name twice
                connectedDevice = dev;
                leftConnected   = true;
                rightConnected  = true; // assume both earbuds for TWS
                break;
            }
        }

        // Also check HFP (headset profile for mic)
        if (btHeadset != null) {
            List<BluetoothDevice> hfpDevices = btHeadset.getConnectedDevices();
            if (!hfpDevices.isEmpty() && connectedDevice == null) {
                connectedDevice = hfpDevices.get(0);
                leftConnected   = true;
                rightConnected  = true;
            }
        }

        runOnUiThread(this::updateDeviceUI);
    }

    private void updateDeviceUI() {
        if (connectedDevice != null) {
            String name = connectedDevice.getName();
            tvDeviceName.setText(name != null ? name : "TWS Device");
            tvCodec.setText("A2DP · aptX");
            tvStatus.setText(leftConnected && rightConnected
                ? "STEREO ATIVO" : leftConnected || rightConnected
                ? "MONO ATIVO"  : "DESCONECTADO");

            ledLeft.setBackgroundResource(leftConnected
                ? R.drawable.led_green : R.drawable.led_off);
            ledRight.setBackgroundResource(rightConnected
                ? R.drawable.led_green : R.drawable.led_off);

            tvBatLeft.setText(leftConnected  ? "L: ~70%" : "L: --");
            tvBatRight.setText(rightConnected ? "R: ~60%" : "R: --");
        } else {
            tvDeviceName.setText("SEM DISPOSITIVO");
            tvCodec.setText("--");
            tvStatus.setText("AGUARDANDO...");
            ledLeft.setBackgroundResource(R.drawable.led_off);
            ledRight.setBackgroundResource(R.drawable.led_off);
            tvBatLeft.setText("L: --");
            tvBatRight.setText("R: --");
        }
    }

    // ──────────────── Sliders ───────────────────
    private void setupSliders() {
        int maxMedia = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curMedia = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int maxMic   = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
        int curMic   = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL);

        sbLeft.setMax(maxMedia);
        sbLeft.setProgress(curMedia);
        sbRight.setMax(maxMedia);
        sbRight.setProgress(curMedia);
        sbMic.setMax(maxMic);
        sbMic.setProgress(curMic);

        tvLeft.setText(pct(curMedia, maxMedia) + "%");
        tvRight.setText(pct(curMedia, maxMedia) + "%");
        tvMic.setText(pct(curMic, maxMic) + "%");

        sbLeft.setOnSeekBarChangeListener(new SeekBarListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
                tvLeft.setText(pct(v, sb.getMax()) + "%");
                if (volumesLinked) {
                    sbRight.setProgress(v);
                    tvRight.setText(pct(v, sb.getMax()) + "%");
                }
            }
        });

        sbRight.setOnSeekBarChangeListener(new SeekBarListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                if (!volumesLinked) {
                    tvRight.setText(pct(v, sb.getMax()) + "%");
                }
            }
        });

        sbMic.setOnSeekBarChangeListener(new SeekBarListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, v, 0);
                tvMic.setText(pct(v, sb.getMax()) + "%");
            }
        });
    }

    // ──────────────── Buttons & Switches ────────
    private void setupButtons() {
        swLink.setChecked(true);
        swLink.setOnCheckedChangeListener((btn, checked) -> {
            volumesLinked = checked;
            showToast(checked ? "Volumes sincronizados" : "Volumes independentes");
        });

        swANC.setOnCheckedChangeListener((btn, checked) ->
            showToast(checked ? "ANC ativado" : "ANC desativado"));

        swMic.setOnCheckedChangeListener((btn, checked) -> {
            audioManager.setMicrophoneMute(!checked);
            showToast(checked ? "Microfone ativo" : "Microfone mudo");
        });

        btnScan.setOnClickListener(v -> startScan());

        View.OnClickListener eqClick = v -> {
            llEqFlat.setSelected(v == llEqFlat);
            llEqBass.setSelected(v == llEqBass);
            llEqVocal.setSelected(v == llEqVocal);
            String eq = v == llEqBass ? "BASS" : v == llEqVocal ? "VOCAL" : "FLAT";
            showToast("EQ: " + eq);
        };
        llEqFlat.setOnClickListener(eqClick);
        llEqBass.setOnClickListener(eqClick);
        llEqVocal.setOnClickListener(eqClick);
    }

    // ──────────────── Scan ──────────────────────
    private void startScan() {
        if (scanning) return;
        scanning = true;
        btnScan.setText("⟳  ESCANEANDO...");
        btnScan.setEnabled(false);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            scanning = false;
            btnScan.setText("⊕  BUSCAR FONE");
            btnScan.setEnabled(true);
            refreshConnectedDevices();
            showToast("Scan concluído");
        }, 3000);
    }

    // ──────────────── Helpers ───────────────────
    private int pct(int val, int max) {
        return max == 0 ? 0 : Math.round(val * 100f / max);
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ──────────────── Permissions ────────────────
    private void requestRequiredPermissions() {
        List<String> perms = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_CONNECT);
            perms.add(Manifest.permission.BLUETOOTH_SCAN);
        }
        perms.add(Manifest.permission.RECORD_AUDIO);
        perms.add(Manifest.permission.MODIFY_AUDIO_SETTINGS);
        perms.add(Manifest.permission.ACCESS_FINE_LOCATION);

        ActivityCompat.requestPermissions(this,
            perms.toArray(new String[0]), REQ_PERM);
    }

    // ──────────────── Lifecycle ──────────────────
    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        if (btAdapter != null && btHeadset != null)
            btAdapter.closeProfileProxy(BluetoothProfile.HEADSET, btHeadset);
    }

    // ──────────────── Inner class ────────────────
    abstract static class SeekBarListener implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar sb) {}
        @Override public void onStopTrackingTouch(SeekBar sb) {}
    }
}
